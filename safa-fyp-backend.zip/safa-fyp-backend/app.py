from flask import Flask, request, jsonify
import torch
import torchaudio
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
import os
import torchaudio
from flask_cors import CORS
import soundfile as sf

app = Flask(__name__)

# Enable CORS for all routes and all origins
CORS(app)

# Ensure the ./files directory exists
os.makedirs('./files', exist_ok=True)

# Load the processor and model
processor = Wav2Vec2Processor.from_pretrained("facebook/wav2vec2-large-960h")
model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-large-960h")
model.eval()

def transcribe_audio(audio_path):
    # Load audio using soundfile (cross-platform)
    waveform, sample_rate = sf.read(audio_path, dtype='float32')
    
    # Convert to tensor
    waveform = torch.tensor(waveform).unsqueeze(0)
    
    # Resample if needed
    if sample_rate != 16000:
        resampler = torchaudio.transforms.Resample(orig_freq=sample_rate, new_freq=16000)
        waveform = resampler(waveform)

    # Process waveform
    input_values = processor(waveform.squeeze().numpy(), return_tensors="pt", sampling_rate=16000).input_values

    # Transcribe
    with torch.no_grad():
        logits = model(input_values).logits
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids)[0]
    
    return transcription.strip()

@app.route('/transcribe', methods=['POST'])
def transcribe():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    file_path = os.path.join('./files', file.filename)
    file.save(file_path)
    transcription = transcribe_audio(file_path)
    os.remove(file_path)

    return jsonify({"transcription": transcription})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
